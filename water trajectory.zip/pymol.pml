# CaverWeb job ID: qyjcpx

cd data

set all_states, 0
set two_sided_lighting, on

# origins - starting point
load origins.pdb, origins
load v_origins.pdb, v_origins
show nb_spheres, origins
show nb_spheres, v_origins

# structure
load structure.pdb, structure
hide lines, structure
hide ribbon, structure
show cartoon, structure
color gray, structure

# pockets
load pocket_4.pdb, pocket_4
alter pocket_4, vdw=b
hide lines, pocket_4
hide spheres, pocket_4
show surface, pocket_4
set transparency, 0.5, pocket_4
color 0xFFA500, pocket_4

# clusters (tunnels)
load rgb.py
load tun_cl_1.pdb, tun_cl_1
alter tun_cl_1, vdw=b
hide lines, tun_cl_1
hide spheres, tun_cl_1
show surface, tun_cl_1
set transparency, 0.3, tun_cl_1
color caver1, tun_cl_1
load tun_cl_2.pdb, tun_cl_2
alter tun_cl_2, vdw=b
hide lines, tun_cl_2
hide spheres, tun_cl_2
show surface, tun_cl_2
set transparency, 0.3, tun_cl_2
color caver2, tun_cl_2
load tun_cl_3.pdb, tun_cl_3
alter tun_cl_3, vdw=b
hide lines, tun_cl_3
hide spheres, tun_cl_3
show surface, tun_cl_3
set transparency, 0.3, tun_cl_3
color caver3, tun_cl_3
load tun_cl_4.pdb, tun_cl_4
alter tun_cl_4, vdw=b
hide lines, tun_cl_4
hide spheres, tun_cl_4
show surface, tun_cl_4
set transparency, 0.3, tun_cl_4
color caver4, tun_cl_4
load tun_cl_5.pdb, tun_cl_5
alter tun_cl_5, vdw=b
hide lines, tun_cl_5
hide spheres, tun_cl_5
show surface, tun_cl_5
set transparency, 0.3, tun_cl_5
color caver5, tun_cl_5
load tun_cl_6.pdb, tun_cl_6
alter tun_cl_6, vdw=b
hide lines, tun_cl_6
hide spheres, tun_cl_6
show surface, tun_cl_6
set transparency, 0.3, tun_cl_6
color caver6, tun_cl_6
load tun_cl_7.pdb, tun_cl_7
alter tun_cl_7, vdw=b
hide lines, tun_cl_7
hide spheres, tun_cl_7
show surface, tun_cl_7
set transparency, 0.3, tun_cl_7
color caver7, tun_cl_7
load tun_cl_8.pdb, tun_cl_8
alter tun_cl_8, vdw=b
hide lines, tun_cl_8
hide spheres, tun_cl_8
show surface, tun_cl_8
set transparency, 0.3, tun_cl_8
color caver8, tun_cl_8
load tun_cl_9.pdb, tun_cl_9
alter tun_cl_9, vdw=b
hide lines, tun_cl_9
hide spheres, tun_cl_9
show surface, tun_cl_9
set transparency, 0.3, tun_cl_9
color caver9, tun_cl_9
load tun_cl_10.pdb, tun_cl_10
alter tun_cl_10, vdw=b
hide lines, tun_cl_10
hide spheres, tun_cl_10
show surface, tun_cl_10
set transparency, 0.3, tun_cl_10
color caver10, tun_cl_10
load tun_cl_11.pdb, tun_cl_11
alter tun_cl_11, vdw=b
hide lines, tun_cl_11
hide spheres, tun_cl_11
show surface, tun_cl_11
set transparency, 0.3, tun_cl_11
color caver11, tun_cl_11
load tun_cl_12.pdb, tun_cl_12
alter tun_cl_12, vdw=b
hide lines, tun_cl_12
hide spheres, tun_cl_12
show surface, tun_cl_12
set transparency, 0.3, tun_cl_12
color caver12, tun_cl_12
load tun_cl_13.pdb, tun_cl_13
alter tun_cl_13, vdw=b
hide lines, tun_cl_13
hide spheres, tun_cl_13
show surface, tun_cl_13
set transparency, 0.3, tun_cl_13
color caver13, tun_cl_13
load tun_cl_14.pdb, tun_cl_14
alter tun_cl_14, vdw=b
hide lines, tun_cl_14
hide spheres, tun_cl_14
show surface, tun_cl_14
set transparency, 0.3, tun_cl_14
color caver14, tun_cl_14
load tun_cl_15.pdb, tun_cl_15
alter tun_cl_15, vdw=b
hide lines, tun_cl_15
hide spheres, tun_cl_15
show surface, tun_cl_15
set transparency, 0.3, tun_cl_15
color caver15, tun_cl_15
load tun_cl_16.pdb, tun_cl_16
alter tun_cl_16, vdw=b
hide lines, tun_cl_16
hide spheres, tun_cl_16
show surface, tun_cl_16
set transparency, 0.3, tun_cl_16
color caver16, tun_cl_16
load tun_cl_17.pdb, tun_cl_17
alter tun_cl_17, vdw=b
hide lines, tun_cl_17
hide spheres, tun_cl_17
show surface, tun_cl_17
set transparency, 0.3, tun_cl_17
color caver17, tun_cl_17
load tun_cl_18.pdb, tun_cl_18
alter tun_cl_18, vdw=b
hide lines, tun_cl_18
hide spheres, tun_cl_18
show surface, tun_cl_18
set transparency, 0.3, tun_cl_18
color caver18, tun_cl_18
load tun_cl_19.pdb, tun_cl_19
alter tun_cl_19, vdw=b
hide lines, tun_cl_19
hide spheres, tun_cl_19
show surface, tun_cl_19
set transparency, 0.3, tun_cl_19
color caver19, tun_cl_19
load tun_cl_20.pdb, tun_cl_20
alter tun_cl_20, vdw=b
hide lines, tun_cl_20
hide spheres, tun_cl_20
show surface, tun_cl_20
set transparency, 0.3, tun_cl_20
color caver20, tun_cl_20
load tun_cl_21.pdb, tun_cl_21
alter tun_cl_21, vdw=b
hide lines, tun_cl_21
hide spheres, tun_cl_21
show surface, tun_cl_21
set transparency, 0.3, tun_cl_21
color caver21, tun_cl_21
load tun_cl_22.pdb, tun_cl_22
alter tun_cl_22, vdw=b
hide lines, tun_cl_22
hide spheres, tun_cl_22
show surface, tun_cl_22
set transparency, 0.3, tun_cl_22
color caver22, tun_cl_22
load tun_cl_23.pdb, tun_cl_23
alter tun_cl_23, vdw=b
hide lines, tun_cl_23
hide spheres, tun_cl_23
show surface, tun_cl_23
set transparency, 0.3, tun_cl_23
color caver23, tun_cl_23
load tun_cl_24.pdb, tun_cl_24
alter tun_cl_24, vdw=b
hide lines, tun_cl_24
hide spheres, tun_cl_24
show surface, tun_cl_24
set transparency, 0.3, tun_cl_24
color caver24, tun_cl_24
load tun_cl_25.pdb, tun_cl_25
alter tun_cl_25, vdw=b
hide lines, tun_cl_25
hide spheres, tun_cl_25
show surface, tun_cl_25
set transparency, 0.3, tun_cl_25
color caver25, tun_cl_25
load tun_cl_26.pdb, tun_cl_26
alter tun_cl_26, vdw=b
hide lines, tun_cl_26
hide spheres, tun_cl_26
show surface, tun_cl_26
set transparency, 0.3, tun_cl_26
color caver26, tun_cl_26
load tun_cl_27.pdb, tun_cl_27
alter tun_cl_27, vdw=b
hide lines, tun_cl_27
hide spheres, tun_cl_27
show surface, tun_cl_27
set transparency, 0.3, tun_cl_27
color caver27, tun_cl_27
load tun_cl_28.pdb, tun_cl_28
alter tun_cl_28, vdw=b
hide lines, tun_cl_28
hide spheres, tun_cl_28
show surface, tun_cl_28
set transparency, 0.3, tun_cl_28
color caver28, tun_cl_28
load tun_cl_29.pdb, tun_cl_29
alter tun_cl_29, vdw=b
hide lines, tun_cl_29
hide spheres, tun_cl_29
show surface, tun_cl_29
set transparency, 0.3, tun_cl_29
color caver29, tun_cl_29
load tun_cl_30.pdb, tun_cl_30
alter tun_cl_30, vdw=b
hide lines, tun_cl_30
hide spheres, tun_cl_30
show surface, tun_cl_30
set transparency, 0.3, tun_cl_30
color caver30, tun_cl_30
load tun_cl_31.pdb, tun_cl_31
alter tun_cl_31, vdw=b
hide lines, tun_cl_31
hide spheres, tun_cl_31
show surface, tun_cl_31
set transparency, 0.3, tun_cl_31
color caver31, tun_cl_31
load tun_cl_32.pdb, tun_cl_32
alter tun_cl_32, vdw=b
hide lines, tun_cl_32
hide spheres, tun_cl_32
show surface, tun_cl_32
set transparency, 0.3, tun_cl_32
color caver32, tun_cl_32
load tun_cl_33.pdb, tun_cl_33
alter tun_cl_33, vdw=b
hide lines, tun_cl_33
hide spheres, tun_cl_33
show surface, tun_cl_33
set transparency, 0.3, tun_cl_33
color caver33, tun_cl_33
load tun_cl_34.pdb, tun_cl_34
alter tun_cl_34, vdw=b
hide lines, tun_cl_34
hide spheres, tun_cl_34
show surface, tun_cl_34
set transparency, 0.3, tun_cl_34
color caver34, tun_cl_34
load tun_cl_35.pdb, tun_cl_35
alter tun_cl_35, vdw=b
hide lines, tun_cl_35
hide spheres, tun_cl_35
show surface, tun_cl_35
set transparency, 0.3, tun_cl_35
color caver35, tun_cl_35
load tun_cl_36.pdb, tun_cl_36
alter tun_cl_36, vdw=b
hide lines, tun_cl_36
hide spheres, tun_cl_36
show surface, tun_cl_36
set transparency, 0.3, tun_cl_36
color caver36, tun_cl_36
load tun_cl_37.pdb, tun_cl_37
alter tun_cl_37, vdw=b
hide lines, tun_cl_37
hide spheres, tun_cl_37
show surface, tun_cl_37
set transparency, 0.3, tun_cl_37
color caver37, tun_cl_37
load tun_cl_38.pdb, tun_cl_38
alter tun_cl_38, vdw=b
hide lines, tun_cl_38
hide spheres, tun_cl_38
show surface, tun_cl_38
set transparency, 0.3, tun_cl_38
color caver38, tun_cl_38
load tun_cl_39.pdb, tun_cl_39
alter tun_cl_39, vdw=b
hide lines, tun_cl_39
hide spheres, tun_cl_39
show surface, tun_cl_39
set transparency, 0.3, tun_cl_39
color caver39, tun_cl_39
load tun_cl_40.pdb, tun_cl_40
alter tun_cl_40, vdw=b
hide lines, tun_cl_40
hide spheres, tun_cl_40
show surface, tun_cl_40
set transparency, 0.3, tun_cl_40
color caver40, tun_cl_40
load tun_cl_41.pdb, tun_cl_41
alter tun_cl_41, vdw=b
hide lines, tun_cl_41
hide spheres, tun_cl_41
show surface, tun_cl_41
set transparency, 0.3, tun_cl_41
color caver41, tun_cl_41
load tun_cl_42.pdb, tun_cl_42
alter tun_cl_42, vdw=b
hide lines, tun_cl_42
hide spheres, tun_cl_42
show surface, tun_cl_42
set transparency, 0.3, tun_cl_42
color caver42, tun_cl_42
load tun_cl_43.pdb, tun_cl_43
alter tun_cl_43, vdw=b
hide lines, tun_cl_43
hide spheres, tun_cl_43
show surface, tun_cl_43
set transparency, 0.3, tun_cl_43
color caver43, tun_cl_43
load tun_cl_44.pdb, tun_cl_44
alter tun_cl_44, vdw=b
hide lines, tun_cl_44
hide spheres, tun_cl_44
show surface, tun_cl_44
set transparency, 0.3, tun_cl_44
color caver44, tun_cl_44
load tun_cl_45.pdb, tun_cl_45
alter tun_cl_45, vdw=b
hide lines, tun_cl_45
hide spheres, tun_cl_45
show surface, tun_cl_45
set transparency, 0.3, tun_cl_45
color caver45, tun_cl_45
load tun_cl_46.pdb, tun_cl_46
alter tun_cl_46, vdw=b
hide lines, tun_cl_46
hide spheres, tun_cl_46
show surface, tun_cl_46
set transparency, 0.3, tun_cl_46
color caver46, tun_cl_46
load tun_cl_47.pdb, tun_cl_47
alter tun_cl_47, vdw=b
hide lines, tun_cl_47
hide spheres, tun_cl_47
show surface, tun_cl_47
set transparency, 0.3, tun_cl_47
color caver47, tun_cl_47
load tun_cl_48.pdb, tun_cl_48
alter tun_cl_48, vdw=b
hide lines, tun_cl_48
hide spheres, tun_cl_48
show surface, tun_cl_48
set transparency, 0.3, tun_cl_48
color caver48, tun_cl_48
load tun_cl_49.pdb, tun_cl_49
alter tun_cl_49, vdw=b
hide lines, tun_cl_49
hide spheres, tun_cl_49
show surface, tun_cl_49
set transparency, 0.3, tun_cl_49
color caver49, tun_cl_49
load tun_cl_50.pdb, tun_cl_50
alter tun_cl_50, vdw=b
hide lines, tun_cl_50
hide spheres, tun_cl_50
show surface, tun_cl_50
set transparency, 0.3, tun_cl_50
color caver50, tun_cl_50
load tun_cl_51.pdb, tun_cl_51
alter tun_cl_51, vdw=b
hide lines, tun_cl_51
hide spheres, tun_cl_51
show surface, tun_cl_51
set transparency, 0.3, tun_cl_51
color caver51, tun_cl_51
load tun_cl_52.pdb, tun_cl_52
alter tun_cl_52, vdw=b
hide lines, tun_cl_52
hide spheres, tun_cl_52
show surface, tun_cl_52
set transparency, 0.3, tun_cl_52
color caver52, tun_cl_52
load tun_cl_53.pdb, tun_cl_53
alter tun_cl_53, vdw=b
hide lines, tun_cl_53
hide spheres, tun_cl_53
show surface, tun_cl_53
set transparency, 0.3, tun_cl_53
color caver53, tun_cl_53
load tun_cl_54.pdb, tun_cl_54
alter tun_cl_54, vdw=b
hide lines, tun_cl_54
hide spheres, tun_cl_54
show surface, tun_cl_54
set transparency, 0.3, tun_cl_54
color caver54, tun_cl_54
load tun_cl_55.pdb, tun_cl_55
alter tun_cl_55, vdw=b
hide lines, tun_cl_55
hide spheres, tun_cl_55
show surface, tun_cl_55
set transparency, 0.3, tun_cl_55
color caver55, tun_cl_55
load tun_cl_56.pdb, tun_cl_56
alter tun_cl_56, vdw=b
hide lines, tun_cl_56
hide spheres, tun_cl_56
show surface, tun_cl_56
set transparency, 0.3, tun_cl_56
color caver56, tun_cl_56
load tun_cl_57.pdb, tun_cl_57
alter tun_cl_57, vdw=b
hide lines, tun_cl_57
hide spheres, tun_cl_57
show surface, tun_cl_57
set transparency, 0.3, tun_cl_57
color caver57, tun_cl_57
load tun_cl_58.pdb, tun_cl_58
alter tun_cl_58, vdw=b
hide lines, tun_cl_58
hide spheres, tun_cl_58
show surface, tun_cl_58
set transparency, 0.3, tun_cl_58
color caver58, tun_cl_58
load tun_cl_59.pdb, tun_cl_59
alter tun_cl_59, vdw=b
hide lines, tun_cl_59
hide spheres, tun_cl_59
show surface, tun_cl_59
set transparency, 0.3, tun_cl_59
color caver59, tun_cl_59
load tun_cl_60.pdb, tun_cl_60
alter tun_cl_60, vdw=b
hide lines, tun_cl_60
hide spheres, tun_cl_60
show surface, tun_cl_60
set transparency, 0.3, tun_cl_60
color caver60, tun_cl_60
load tun_cl_61.pdb, tun_cl_61
alter tun_cl_61, vdw=b
hide lines, tun_cl_61
hide spheres, tun_cl_61
show surface, tun_cl_61
set transparency, 0.3, tun_cl_61
color caver61, tun_cl_61
load tun_cl_62.pdb, tun_cl_62
alter tun_cl_62, vdw=b
hide lines, tun_cl_62
hide spheres, tun_cl_62
show surface, tun_cl_62
set transparency, 0.3, tun_cl_62
color caver62, tun_cl_62
load tun_cl_63.pdb, tun_cl_63
alter tun_cl_63, vdw=b
hide lines, tun_cl_63
hide spheres, tun_cl_63
show surface, tun_cl_63
set transparency, 0.3, tun_cl_63
color caver63, tun_cl_63
load tun_cl_64.pdb, tun_cl_64
alter tun_cl_64, vdw=b
hide lines, tun_cl_64
hide spheres, tun_cl_64
show surface, tun_cl_64
set transparency, 0.3, tun_cl_64
color caver64, tun_cl_64
load tun_cl_65.pdb, tun_cl_65
alter tun_cl_65, vdw=b
hide lines, tun_cl_65
hide spheres, tun_cl_65
show surface, tun_cl_65
set transparency, 0.3, tun_cl_65
color caver65, tun_cl_65
load tun_cl_66.pdb, tun_cl_66
alter tun_cl_66, vdw=b
hide lines, tun_cl_66
hide spheres, tun_cl_66
show surface, tun_cl_66
set transparency, 0.3, tun_cl_66
color caver66, tun_cl_66
load tun_cl_67.pdb, tun_cl_67
alter tun_cl_67, vdw=b
hide lines, tun_cl_67
hide spheres, tun_cl_67
show surface, tun_cl_67
set transparency, 0.3, tun_cl_67
color caver67, tun_cl_67
load tun_cl_68.pdb, tun_cl_68
alter tun_cl_68, vdw=b
hide lines, tun_cl_68
hide spheres, tun_cl_68
show surface, tun_cl_68
set transparency, 0.3, tun_cl_68
color caver68, tun_cl_68
load tun_cl_69.pdb, tun_cl_69
alter tun_cl_69, vdw=b
hide lines, tun_cl_69
hide spheres, tun_cl_69
show surface, tun_cl_69
set transparency, 0.3, tun_cl_69
color caver69, tun_cl_69
load tun_cl_70.pdb, tun_cl_70
alter tun_cl_70, vdw=b
hide lines, tun_cl_70
hide spheres, tun_cl_70
show surface, tun_cl_70
set transparency, 0.3, tun_cl_70
color caver70, tun_cl_70
load tun_cl_71.pdb, tun_cl_71
alter tun_cl_71, vdw=b
hide lines, tun_cl_71
hide spheres, tun_cl_71
show surface, tun_cl_71
set transparency, 0.3, tun_cl_71
color caver71, tun_cl_71
load tun_cl_72.pdb, tun_cl_72
alter tun_cl_72, vdw=b
hide lines, tun_cl_72
hide spheres, tun_cl_72
show surface, tun_cl_72
set transparency, 0.3, tun_cl_72
color caver72, tun_cl_72
load tun_cl_73.pdb, tun_cl_73
alter tun_cl_73, vdw=b
hide lines, tun_cl_73
hide spheres, tun_cl_73
show surface, tun_cl_73
set transparency, 0.3, tun_cl_73
color caver73, tun_cl_73
load tun_cl_74.pdb, tun_cl_74
alter tun_cl_74, vdw=b
hide lines, tun_cl_74
hide spheres, tun_cl_74
show surface, tun_cl_74
set transparency, 0.3, tun_cl_74
color caver74, tun_cl_74
load tun_cl_75.pdb, tun_cl_75
alter tun_cl_75, vdw=b
hide lines, tun_cl_75
hide spheres, tun_cl_75
show surface, tun_cl_75
set transparency, 0.3, tun_cl_75
color caver75, tun_cl_75
load tun_cl_76.pdb, tun_cl_76
alter tun_cl_76, vdw=b
hide lines, tun_cl_76
hide spheres, tun_cl_76
show surface, tun_cl_76
set transparency, 0.3, tun_cl_76
color caver76, tun_cl_76
load tun_cl_77.pdb, tun_cl_77
alter tun_cl_77, vdw=b
hide lines, tun_cl_77
hide spheres, tun_cl_77
show surface, tun_cl_77
set transparency, 0.3, tun_cl_77
color caver77, tun_cl_77
load tun_cl_78.pdb, tun_cl_78
alter tun_cl_78, vdw=b
hide lines, tun_cl_78
hide spheres, tun_cl_78
show surface, tun_cl_78
set transparency, 0.3, tun_cl_78
color caver78, tun_cl_78
load tun_cl_79.pdb, tun_cl_79
alter tun_cl_79, vdw=b
hide lines, tun_cl_79
hide spheres, tun_cl_79
show surface, tun_cl_79
set transparency, 0.3, tun_cl_79
color caver79, tun_cl_79
load tun_cl_80.pdb, tun_cl_80
alter tun_cl_80, vdw=b
hide lines, tun_cl_80
hide spheres, tun_cl_80
show surface, tun_cl_80
set transparency, 0.3, tun_cl_80
color caver80, tun_cl_80
load tun_cl_81.pdb, tun_cl_81
alter tun_cl_81, vdw=b
hide lines, tun_cl_81
hide spheres, tun_cl_81
show surface, tun_cl_81
set transparency, 0.3, tun_cl_81
color caver81, tun_cl_81
load tun_cl_82.pdb, tun_cl_82
alter tun_cl_82, vdw=b
hide lines, tun_cl_82
hide spheres, tun_cl_82
show surface, tun_cl_82
set transparency, 0.3, tun_cl_82
color caver82, tun_cl_82
load tun_cl_83.pdb, tun_cl_83
alter tun_cl_83, vdw=b
hide lines, tun_cl_83
hide spheres, tun_cl_83
show surface, tun_cl_83
set transparency, 0.3, tun_cl_83
color caver83, tun_cl_83
load tun_cl_84.pdb, tun_cl_84
alter tun_cl_84, vdw=b
hide lines, tun_cl_84
hide spheres, tun_cl_84
show surface, tun_cl_84
set transparency, 0.3, tun_cl_84
color caver84, tun_cl_84
load tun_cl_85.pdb, tun_cl_85
alter tun_cl_85, vdw=b
hide lines, tun_cl_85
hide spheres, tun_cl_85
show surface, tun_cl_85
set transparency, 0.3, tun_cl_85
color caver85, tun_cl_85
load tun_cl_86.pdb, tun_cl_86
alter tun_cl_86, vdw=b
hide lines, tun_cl_86
hide spheres, tun_cl_86
show surface, tun_cl_86
set transparency, 0.3, tun_cl_86
color caver86, tun_cl_86
load tun_cl_87.pdb, tun_cl_87
alter tun_cl_87, vdw=b
hide lines, tun_cl_87
hide spheres, tun_cl_87
show surface, tun_cl_87
set transparency, 0.3, tun_cl_87
color caver87, tun_cl_87
load tun_cl_88.pdb, tun_cl_88
alter tun_cl_88, vdw=b
hide lines, tun_cl_88
hide spheres, tun_cl_88
show surface, tun_cl_88
set transparency, 0.3, tun_cl_88
color caver88, tun_cl_88
load tun_cl_89.pdb, tun_cl_89
alter tun_cl_89, vdw=b
hide lines, tun_cl_89
hide spheres, tun_cl_89
show surface, tun_cl_89
set transparency, 0.3, tun_cl_89
color caver89, tun_cl_89
load tun_cl_90.pdb, tun_cl_90
alter tun_cl_90, vdw=b
hide lines, tun_cl_90
hide spheres, tun_cl_90
show surface, tun_cl_90
set transparency, 0.3, tun_cl_90
color caver90, tun_cl_90
load tun_cl_91.pdb, tun_cl_91
alter tun_cl_91, vdw=b
hide lines, tun_cl_91
hide spheres, tun_cl_91
show surface, tun_cl_91
set transparency, 0.3, tun_cl_91
color caver91, tun_cl_91
load tun_cl_92.pdb, tun_cl_92
alter tun_cl_92, vdw=b
hide lines, tun_cl_92
hide spheres, tun_cl_92
show surface, tun_cl_92
set transparency, 0.3, tun_cl_92
color caver92, tun_cl_92
load tun_cl_93.pdb, tun_cl_93
alter tun_cl_93, vdw=b
hide lines, tun_cl_93
hide spheres, tun_cl_93
show surface, tun_cl_93
set transparency, 0.3, tun_cl_93
color caver93, tun_cl_93
load tun_cl_94.pdb, tun_cl_94
alter tun_cl_94, vdw=b
hide lines, tun_cl_94
hide spheres, tun_cl_94
show surface, tun_cl_94
set transparency, 0.3, tun_cl_94
color caver94, tun_cl_94
load tun_cl_95.pdb, tun_cl_95
alter tun_cl_95, vdw=b
hide lines, tun_cl_95
hide spheres, tun_cl_95
show surface, tun_cl_95
set transparency, 0.3, tun_cl_95
color caver95, tun_cl_95
load tun_cl_96.pdb, tun_cl_96
alter tun_cl_96, vdw=b
hide lines, tun_cl_96
hide spheres, tun_cl_96
show surface, tun_cl_96
set transparency, 0.3, tun_cl_96
color caver96, tun_cl_96
load tun_cl_97.pdb, tun_cl_97
alter tun_cl_97, vdw=b
hide lines, tun_cl_97
hide spheres, tun_cl_97
show surface, tun_cl_97
set transparency, 0.3, tun_cl_97
color caver97, tun_cl_97
load tun_cl_98.pdb, tun_cl_98
alter tun_cl_98, vdw=b
hide lines, tun_cl_98
hide spheres, tun_cl_98
show surface, tun_cl_98
set transparency, 0.3, tun_cl_98
color caver98, tun_cl_98
load tun_cl_99.pdb, tun_cl_99
alter tun_cl_99, vdw=b
hide lines, tun_cl_99
hide spheres, tun_cl_99
show surface, tun_cl_99
set transparency, 0.3, tun_cl_99
color caver99, tun_cl_99
load tun_cl_100.pdb, tun_cl_100
alter tun_cl_100, vdw=b
hide lines, tun_cl_100
hide spheres, tun_cl_100
show surface, tun_cl_100
set transparency, 0.3, tun_cl_100
color caver100, tun_cl_100
load tun_cl_101.pdb, tun_cl_101
alter tun_cl_101, vdw=b
hide lines, tun_cl_101
hide spheres, tun_cl_101
show surface, tun_cl_101
set transparency, 0.3, tun_cl_101
color caver101, tun_cl_101
load tun_cl_102.pdb, tun_cl_102
alter tun_cl_102, vdw=b
hide lines, tun_cl_102
hide spheres, tun_cl_102
show surface, tun_cl_102
set transparency, 0.3, tun_cl_102
color caver102, tun_cl_102
load tun_cl_103.pdb, tun_cl_103
alter tun_cl_103, vdw=b
hide lines, tun_cl_103
hide spheres, tun_cl_103
show surface, tun_cl_103
set transparency, 0.3, tun_cl_103
color caver103, tun_cl_103
load tun_cl_104.pdb, tun_cl_104
alter tun_cl_104, vdw=b
hide lines, tun_cl_104
hide spheres, tun_cl_104
show surface, tun_cl_104
set transparency, 0.3, tun_cl_104
color caver104, tun_cl_104
load tun_cl_105.pdb, tun_cl_105
alter tun_cl_105, vdw=b
hide lines, tun_cl_105
hide spheres, tun_cl_105
show surface, tun_cl_105
set transparency, 0.3, tun_cl_105
color caver105, tun_cl_105
load tun_cl_106.pdb, tun_cl_106
alter tun_cl_106, vdw=b
hide lines, tun_cl_106
hide spheres, tun_cl_106
show surface, tun_cl_106
set transparency, 0.3, tun_cl_106
color caver106, tun_cl_106
load tun_cl_107.pdb, tun_cl_107
alter tun_cl_107, vdw=b
hide lines, tun_cl_107
hide spheres, tun_cl_107
show surface, tun_cl_107
set transparency, 0.3, tun_cl_107
color caver107, tun_cl_107
load tun_cl_108.pdb, tun_cl_108
alter tun_cl_108, vdw=b
hide lines, tun_cl_108
hide spheres, tun_cl_108
show surface, tun_cl_108
set transparency, 0.3, tun_cl_108
color caver108, tun_cl_108
load tun_cl_109.pdb, tun_cl_109
alter tun_cl_109, vdw=b
hide lines, tun_cl_109
hide spheres, tun_cl_109
show surface, tun_cl_109
set transparency, 0.3, tun_cl_109
color caver109, tun_cl_109
load tun_cl_110.pdb, tun_cl_110
alter tun_cl_110, vdw=b
hide lines, tun_cl_110
hide spheres, tun_cl_110
show surface, tun_cl_110
set transparency, 0.3, tun_cl_110
color caver110, tun_cl_110
load tun_cl_111.pdb, tun_cl_111
alter tun_cl_111, vdw=b
hide lines, tun_cl_111
hide spheres, tun_cl_111
show surface, tun_cl_111
set transparency, 0.3, tun_cl_111
color caver111, tun_cl_111
load tun_cl_112.pdb, tun_cl_112
alter tun_cl_112, vdw=b
hide lines, tun_cl_112
hide spheres, tun_cl_112
show surface, tun_cl_112
set transparency, 0.3, tun_cl_112
color caver112, tun_cl_112
load tun_cl_113.pdb, tun_cl_113
alter tun_cl_113, vdw=b
hide lines, tun_cl_113
hide spheres, tun_cl_113
show surface, tun_cl_113
set transparency, 0.3, tun_cl_113
color caver113, tun_cl_113
load tun_cl_114.pdb, tun_cl_114
alter tun_cl_114, vdw=b
hide lines, tun_cl_114
hide spheres, tun_cl_114
show surface, tun_cl_114
set transparency, 0.3, tun_cl_114
color caver114, tun_cl_114
load tun_cl_115.pdb, tun_cl_115
alter tun_cl_115, vdw=b
hide lines, tun_cl_115
hide spheres, tun_cl_115
show surface, tun_cl_115
set transparency, 0.3, tun_cl_115
color caver115, tun_cl_115
load tun_cl_116.pdb, tun_cl_116
alter tun_cl_116, vdw=b
hide lines, tun_cl_116
hide spheres, tun_cl_116
show surface, tun_cl_116
set transparency, 0.3, tun_cl_116
color caver116, tun_cl_116
load tun_cl_117.pdb, tun_cl_117
alter tun_cl_117, vdw=b
hide lines, tun_cl_117
hide spheres, tun_cl_117
show surface, tun_cl_117
set transparency, 0.3, tun_cl_117
color caver117, tun_cl_117
load tun_cl_118.pdb, tun_cl_118
alter tun_cl_118, vdw=b
hide lines, tun_cl_118
hide spheres, tun_cl_118
show surface, tun_cl_118
set transparency, 0.3, tun_cl_118
color caver118, tun_cl_118
load tun_cl_119.pdb, tun_cl_119
alter tun_cl_119, vdw=b
hide lines, tun_cl_119
hide spheres, tun_cl_119
show surface, tun_cl_119
set transparency, 0.3, tun_cl_119
color caver119, tun_cl_119
load tun_cl_120.pdb, tun_cl_120
alter tun_cl_120, vdw=b
hide lines, tun_cl_120
hide spheres, tun_cl_120
show surface, tun_cl_120
set transparency, 0.3, tun_cl_120
color caver120, tun_cl_120
load tun_cl_121.pdb, tun_cl_121
alter tun_cl_121, vdw=b
hide lines, tun_cl_121
hide spheres, tun_cl_121
show surface, tun_cl_121
set transparency, 0.3, tun_cl_121
color caver121, tun_cl_121
load tun_cl_122.pdb, tun_cl_122
alter tun_cl_122, vdw=b
hide lines, tun_cl_122
hide spheres, tun_cl_122
show surface, tun_cl_122
set transparency, 0.3, tun_cl_122
color caver122, tun_cl_122
load tun_cl_123.pdb, tun_cl_123
alter tun_cl_123, vdw=b
hide lines, tun_cl_123
hide spheres, tun_cl_123
show surface, tun_cl_123
set transparency, 0.3, tun_cl_123
color caver123, tun_cl_123
load tun_cl_124.pdb, tun_cl_124
alter tun_cl_124, vdw=b
hide lines, tun_cl_124
hide spheres, tun_cl_124
show surface, tun_cl_124
set transparency, 0.3, tun_cl_124
color caver124, tun_cl_124
load tun_cl_125.pdb, tun_cl_125
alter tun_cl_125, vdw=b
hide lines, tun_cl_125
hide spheres, tun_cl_125
show surface, tun_cl_125
set transparency, 0.3, tun_cl_125
color caver125, tun_cl_125
load tun_cl_126.pdb, tun_cl_126
alter tun_cl_126, vdw=b
hide lines, tun_cl_126
hide spheres, tun_cl_126
show surface, tun_cl_126
set transparency, 0.3, tun_cl_126
color caver126, tun_cl_126
load tun_cl_127.pdb, tun_cl_127
alter tun_cl_127, vdw=b
hide lines, tun_cl_127
hide spheres, tun_cl_127
show surface, tun_cl_127
set transparency, 0.3, tun_cl_127
color caver127, tun_cl_127
load tun_cl_128.pdb, tun_cl_128
alter tun_cl_128, vdw=b
hide lines, tun_cl_128
hide spheres, tun_cl_128
show surface, tun_cl_128
set transparency, 0.3, tun_cl_128
color caver128, tun_cl_128
load tun_cl_129.pdb, tun_cl_129
alter tun_cl_129, vdw=b
hide lines, tun_cl_129
hide spheres, tun_cl_129
show surface, tun_cl_129
set transparency, 0.3, tun_cl_129
color caver129, tun_cl_129
load tun_cl_130.pdb, tun_cl_130
alter tun_cl_130, vdw=b
hide lines, tun_cl_130
hide spheres, tun_cl_130
show surface, tun_cl_130
set transparency, 0.3, tun_cl_130
color caver130, tun_cl_130
load tun_cl_131.pdb, tun_cl_131
alter tun_cl_131, vdw=b
hide lines, tun_cl_131
hide spheres, tun_cl_131
show surface, tun_cl_131
set transparency, 0.3, tun_cl_131
color caver131, tun_cl_131
load tun_cl_132.pdb, tun_cl_132
alter tun_cl_132, vdw=b
hide lines, tun_cl_132
hide spheres, tun_cl_132
show surface, tun_cl_132
set transparency, 0.3, tun_cl_132
color caver132, tun_cl_132
load tun_cl_133.pdb, tun_cl_133
alter tun_cl_133, vdw=b
hide lines, tun_cl_133
hide spheres, tun_cl_133
show surface, tun_cl_133
set transparency, 0.3, tun_cl_133
color caver133, tun_cl_133
load tun_cl_134.pdb, tun_cl_134
alter tun_cl_134, vdw=b
hide lines, tun_cl_134
hide spheres, tun_cl_134
show surface, tun_cl_134
set transparency, 0.3, tun_cl_134
color caver134, tun_cl_134
load tun_cl_135.pdb, tun_cl_135
alter tun_cl_135, vdw=b
hide lines, tun_cl_135
hide spheres, tun_cl_135
show surface, tun_cl_135
set transparency, 0.3, tun_cl_135
color caver135, tun_cl_135
load tun_cl_136.pdb, tun_cl_136
alter tun_cl_136, vdw=b
hide lines, tun_cl_136
hide spheres, tun_cl_136
show surface, tun_cl_136
set transparency, 0.3, tun_cl_136
color caver136, tun_cl_136
load tun_cl_137.pdb, tun_cl_137
alter tun_cl_137, vdw=b
hide lines, tun_cl_137
hide spheres, tun_cl_137
show surface, tun_cl_137
set transparency, 0.3, tun_cl_137
color caver137, tun_cl_137
load tun_cl_138.pdb, tun_cl_138
alter tun_cl_138, vdw=b
hide lines, tun_cl_138
hide spheres, tun_cl_138
show surface, tun_cl_138
set transparency, 0.3, tun_cl_138
color caver138, tun_cl_138
load tun_cl_139.pdb, tun_cl_139
alter tun_cl_139, vdw=b
hide lines, tun_cl_139
hide spheres, tun_cl_139
show surface, tun_cl_139
set transparency, 0.3, tun_cl_139
color caver139, tun_cl_139
load tun_cl_140.pdb, tun_cl_140
alter tun_cl_140, vdw=b
hide lines, tun_cl_140
hide spheres, tun_cl_140
show surface, tun_cl_140
set transparency, 0.3, tun_cl_140
color caver140, tun_cl_140
load tun_cl_141.pdb, tun_cl_141
alter tun_cl_141, vdw=b
hide lines, tun_cl_141
hide spheres, tun_cl_141
show surface, tun_cl_141
set transparency, 0.3, tun_cl_141
color caver141, tun_cl_141
load tun_cl_142.pdb, tun_cl_142
alter tun_cl_142, vdw=b
hide lines, tun_cl_142
hide spheres, tun_cl_142
show surface, tun_cl_142
set transparency, 0.3, tun_cl_142
color caver142, tun_cl_142
load tun_cl_143.pdb, tun_cl_143
alter tun_cl_143, vdw=b
hide lines, tun_cl_143
hide spheres, tun_cl_143
show surface, tun_cl_143
set transparency, 0.3, tun_cl_143
color caver143, tun_cl_143
load tun_cl_144.pdb, tun_cl_144
alter tun_cl_144, vdw=b
hide lines, tun_cl_144
hide spheres, tun_cl_144
show surface, tun_cl_144
set transparency, 0.3, tun_cl_144
color caver144, tun_cl_144
load tun_cl_145.pdb, tun_cl_145
alter tun_cl_145, vdw=b
hide lines, tun_cl_145
hide spheres, tun_cl_145
show surface, tun_cl_145
set transparency, 0.3, tun_cl_145
color caver145, tun_cl_145
load tun_cl_146.pdb, tun_cl_146
alter tun_cl_146, vdw=b
hide lines, tun_cl_146
hide spheres, tun_cl_146
show surface, tun_cl_146
set transparency, 0.3, tun_cl_146
color caver146, tun_cl_146
load tun_cl_147.pdb, tun_cl_147
alter tun_cl_147, vdw=b
hide lines, tun_cl_147
hide spheres, tun_cl_147
show surface, tun_cl_147
set transparency, 0.3, tun_cl_147
color caver147, tun_cl_147
load tun_cl_148.pdb, tun_cl_148
alter tun_cl_148, vdw=b
hide lines, tun_cl_148
hide spheres, tun_cl_148
show surface, tun_cl_148
set transparency, 0.3, tun_cl_148
color caver148, tun_cl_148
load tun_cl_149.pdb, tun_cl_149
alter tun_cl_149, vdw=b
hide lines, tun_cl_149
hide spheres, tun_cl_149
show surface, tun_cl_149
set transparency, 0.3, tun_cl_149
color caver149, tun_cl_149
load tun_cl_150.pdb, tun_cl_150
alter tun_cl_150, vdw=b
hide lines, tun_cl_150
hide spheres, tun_cl_150
show surface, tun_cl_150
set transparency, 0.3, tun_cl_150
color caver150, tun_cl_150
load tun_cl_151.pdb, tun_cl_151
alter tun_cl_151, vdw=b
hide lines, tun_cl_151
hide spheres, tun_cl_151
show surface, tun_cl_151
set transparency, 0.3, tun_cl_151
color caver151, tun_cl_151
load tun_cl_152.pdb, tun_cl_152
alter tun_cl_152, vdw=b
hide lines, tun_cl_152
hide spheres, tun_cl_152
show surface, tun_cl_152
set transparency, 0.3, tun_cl_152
color caver152, tun_cl_152
load tun_cl_153.pdb, tun_cl_153
alter tun_cl_153, vdw=b
hide lines, tun_cl_153
hide spheres, tun_cl_153
show surface, tun_cl_153
set transparency, 0.3, tun_cl_153
color caver153, tun_cl_153
load tun_cl_154.pdb, tun_cl_154
alter tun_cl_154, vdw=b
hide lines, tun_cl_154
hide spheres, tun_cl_154
show surface, tun_cl_154
set transparency, 0.3, tun_cl_154
color caver154, tun_cl_154
load tun_cl_155.pdb, tun_cl_155
alter tun_cl_155, vdw=b
hide lines, tun_cl_155
hide spheres, tun_cl_155
show surface, tun_cl_155
set transparency, 0.3, tun_cl_155
color caver155, tun_cl_155
load tun_cl_156.pdb, tun_cl_156
alter tun_cl_156, vdw=b
hide lines, tun_cl_156
hide spheres, tun_cl_156
show surface, tun_cl_156
set transparency, 0.3, tun_cl_156
color caver156, tun_cl_156
load tun_cl_157.pdb, tun_cl_157
alter tun_cl_157, vdw=b
hide lines, tun_cl_157
hide spheres, tun_cl_157
show surface, tun_cl_157
set transparency, 0.3, tun_cl_157
color caver157, tun_cl_157
load tun_cl_158.pdb, tun_cl_158
alter tun_cl_158, vdw=b
hide lines, tun_cl_158
hide spheres, tun_cl_158
show surface, tun_cl_158
set transparency, 0.3, tun_cl_158
color caver158, tun_cl_158

# ligands

load draw_box.py

# receptor
load "receptor_vdbkrfpryp.pdbqt", "receptor_vdbkrfpryp"
# vina grid
draw_box center=(152.0000, 144.0000, 178.0000), size=(30.0000, 30.0000, 30.0000), spacing=1, linewidth=3, color=(255, 255, 255), name=box_vdbkrfpryp

# vina ligands - poses

group vina_vdbkrfpryp, box_vdbkrfpryp
group vina_vdbkrfpryp,, open

# CD ligands - trajectory
load "trajectory/0_vdbkrfpryp.pdbqt", "traj_0_vdbkrfpryp"
load "trajectory/1_vdbkrfpryp.pdbqt", "traj_1_vdbkrfpryp"
load "trajectory/2_vdbkrfpryp.pdbqt", "traj_2_vdbkrfpryp"
load "trajectory/3_vdbkrfpryp.pdbqt", "traj_3_vdbkrfpryp"

group traj_vdbkrfpryp, traj_0_vdbkrfpryp traj_1_vdbkrfpryp traj_2_vdbkrfpryp traj_3_vdbkrfpryp
group traj_vdbkrfpryp,, open

group screening_vdbkrfpryp, receptor_vdbkrfpryp vina_vdbkrfpryp traj_vdbkrfpryp
group screening_vdbkrfpryp,, open

